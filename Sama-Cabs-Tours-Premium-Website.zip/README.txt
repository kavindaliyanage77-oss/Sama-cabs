SAMA CABS & TOURS — PREMIUM WEBSITE
Extract the ZIP and keep the assets folder beside index.html.
Open index.html in Chrome/Edge/Firefox.
Features: responsive design, supplied logo/photos, airport transfers, hotel transfers, day tours, wedding hire, fleet showcase, Rs.100/km Flex, Rs.120/km Sedan, long-distance quote, WhatsApp booking form and contact buttons.
Suggested domain names to check: samacabstours.lk, samacabstours.com, samataxi.lk. Domain availability should be checked with a registrar before purchase.
